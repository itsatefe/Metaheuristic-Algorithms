/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/


#ifndef POSITIONS_H
#define POSITIONS_H

#ifdef __cplusplus
	extern "C" {
#endif


#include "struct2d.h"

#define POSITIONS_ON_WIDTHS 1
#define POSITIONS_ON_HEIGHTS 2
#define POSITIONS_ON_LENGTHS 3

#define POSITIONS_LEFT_ORIENTED 3
#define POSITIONS_MIM 4


#define POSITIONS_METHOD_CHRISTOFIDES 1
#define POSITIONS_METHOD_BOSCHETTI 2
#define POSITIONS_METHOD_COTE 3
#define POSITIONS_METHOD_REDUCED_RASTERS 4
#define POSITIONS_METHOD_MINIMAL_MIM 5 				//MIM Obtained with the best split
#define POSITIONS_METHOD_MIM_W2 6 					//MIM with a split in W/2
#define POSITIONS_METHOD_MIM_RESTRICT_W2 7 			//MIM with a split in W/2 and a restriction of the smallest
#define POSITIONS_METHOD_GRAPH_MINIMAL_MIM 8		//MIM obtained from the graph_positions procedure
#define POSITIONS_METHOD_MIM_W2_ORIENTATION 9
#define POSITIONS_METHOD_MIM_T_PROVIDED 10
#define POSITIONS_METHOD_MIM_T_PROVIDED_ORIENTATION 11

typedef struct positions* positions_ptr;
typedef struct positions
{
	int * pos;
	int nb;
} positions_t;


typedef struct positions_set* positions_set_ptr;
typedef struct positions_set
{
	positions_t * set;
	int nbsets;
	int * pos;
	int nb;
	int nb_total_positions;
	int split_pos;
} positions_set_t;

void positions_free(positions_set_ptr pos_set);
void positions_show(positions_set_ptr p);
void positions_show_detailed(strip_ptr st,positions_set_ptr p);
void positions_show_global(positions_set_ptr p);

int positions_count_left(positions_set_ptr p);
int positions_count_right(positions_set_ptr p);

int positions_count_left_w(positions_set_ptr p);
int positions_count_right_w(positions_set_ptr p);

//generate positions according to the method
void positions_calc_methods(strip_ptr st, positions_set_ptr p, int method);


void positions_calc_w_christofides(strip_ptr st, positions_set_ptr p);		//from Christofides and Whitlock
void positions_calc_w_boschetti(strip_ptr st, positions_set_ptr p);			//from Boschetti and Montaletti
void positions_calc_w_cote(strip_ptr st, positions_set_ptr p);				//From Cote, Dell'Amico and Iori
void positions_calc_w_reduced_rasters(strip_ptr, positions_set_ptr p);		//from Scheithauer
void positions_calc_w_reduced_rasters_boschetti(strip_ptr,positions_set_ptr p); //Insertsection of reduced raster and boschetti
void positions_calc_w_reduced_rasters_cote(strip_ptr,positions_set_ptr p); //Insertsection of reduced raster and cote
void positions_calc_w_further_reduced(strip_ptr st, positions_set_ptr p);


//all coordinates are left oriented
//provide the set of coordinates for the widths in w[]
//equals[i][j] = 1 if the dimensions of items i and j are of equal size, 0 otherwise
//equals can also be null
void positions_left_oriented(int W, int * w,int n, positions_set_ptr p, int ** equals);
void positions_mim_oriented(int W, int * w,int n, positions_set_ptr p, int ** equals);


void positions_calculate(strip_ptr,positions_set_ptr p, int dimension, int type_pattern);







//old code for MIM
void positions_calc_w_mim(strip_ptr st, positions_set_ptr p);



void positions_calc_w_mim_reduced(strip_ptr st, positions_set_ptr p);


//mim patterns with the cut at w2
void positions_calc_w_mim_split(strip_ptr st, positions_set_ptr p, int w2);

//mim patterns and restrict the smallest to be in the largest partition
void positions_calc_w_mim_split_restrict(strip_ptr st, positions_set_ptr p, int t);
void positions_calc_w_mim_split_restrict_item(strip_ptr st, positions_set_ptr p, int item_restr, int t);

//mim patterns with the cut at w2 and it takes into account the orientation of items
void positions_calc_w_mim_split_orientation(strip_ptr st, positions_set_ptr p, int w2);

//mim patterns and the split is done is the best possible way (without any preprocessing)
//best split is done to minimize the total of patterns for all items
int positions_calculate_mim_best_split(strip_ptr st, positions_set_ptr p);


//mim patterns and the split is done is the best possible way (without any preprocessing)
//best split is done to minimize the total number of columns
int positions_calculate_mim_best_split_w(strip_ptr st, positions_set_ptr p);

//mim patterns and the split is done is the best possible way for the BPP and 1 is to restrict the smallest in the biggest partition
int positions_calculate_mim_best_split_bpp(strip_ptr st, positions_set_ptr p);

//mim patterns and the split is done is the best possible way for the BPP, first patterns have to start with an item of height equal to the strip height
int positions_calculate_mim_best_split_bpp_starting_h(strip_ptr st, positions_set_ptr p);


//mim patterns and the split is done is the best possible way and it takes into account the orientation of items
int positions_calculate_mim_best_split_orientation(strip_ptr st, positions_set_ptr p);


//for each item i, eliminate a position p if p+w_i >  W-minw and p+w_i < W
void positions_reduce1(strip_ptr st, positions_set_ptr p);

void positions_reduce2(strip_ptr st, positions_set_ptr p);

void positions_calculate_on_heights(item_ptr items,int n, int H, positions_set_ptr p);


//Take the positions from p1 and create an array for each item that identify if position p is in p1 or not (1 or 0)
void positions_replace_to_01_on_w(strip_ptr st,int dim, positions_set_ptr p1, positions_set_ptr p2);



//
void positions_create(int n, int * w, int W, int *Pos) ;

void positions_create_nb(int n, int * w, int W, int *Pos);


void positions_create_half(int n,int * w, int W, int * pos);


void strip_set_nb_normal_patterns(strip_ptr st);
int strip_better_to_rotate(strip_ptr st);
void strip_set_possible_heights(strip_ptr st);


#ifdef __cplusplus
	}
#endif

#endif
