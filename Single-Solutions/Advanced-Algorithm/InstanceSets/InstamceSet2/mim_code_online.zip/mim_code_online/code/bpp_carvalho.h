/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#ifndef BPP_CARVALHO_METHOD
#define BPP_CARVALHO_METHOD

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <ilcplex/ilocplex.h>
#include "struct2d.h"
#include "time.h"
#include <vector>

#define BPP_CARVALHO 0
#define BPP_CARVALHO_MIM 1

typedef struct bpp_carvalho_arc
{
	int index;
	int from;
	int to;
	int w;
	item_ptr item;
	char flag;
} bpp_carvalho_arc_t;
typedef struct bpp_carvalho_arc* bpp_carvalho_arc_ptr;

typedef struct
{
	int pos;
	std::vector<bpp_carvalho_arc_ptr> arcs;
	std::vector<bpp_carvalho_arc_ptr> in_arcs;
	bool HasArcs(){return arcs.size() >= 1;}
	bool HasInArcs(){return in_arcs.size() >= 1;}
	int GetLastArcWidth(){return arcs.size() == 0?-1:arcs[ arcs.size() - 1]->w;}
	int GetLastInArcWidth(){return in_arcs.size() == 0?-1:in_arcs[ in_arcs.size() - 1]->w;}
	bool ContainsInArcsOfW(int w)
	{
		for(size_t i=0;i<in_arcs.size();i++)
			if(in_arcs[i]->w == w)
				return true;
		return false;
	}
	bool ContainsArcsOfW(int w)
	{
		for(size_t i=0;i<arcs.size();i++)
			if(arcs[i]->w == w)
				return true;
		return false;
	}

	bpp_carvalho_arc_ptr GetLastArc(){return arcs.size() == 0?NULL:arcs[ arcs.size() - 1];}
	bpp_carvalho_arc_ptr GetLastArcIn(){return in_arcs.size() == 0?NULL:in_arcs[ in_arcs.size() - 1];}

	void RemoveArc(bpp_carvalho_arc_ptr a)
	{
		bool found = false;
		for(size_t i=0;i<arcs.size();i++)
			if(arcs[i] == a)
			{
				found = true;
				arcs.erase(arcs.begin() + i);
				break;
			}
		if(!found)
			printf("Error RemoveArc from:%d to:%d item:%d\n", a->from, a->to, a->item->origin_id);
	}

	void RemoveInArc(bpp_carvalho_arc_ptr a)
	{
		bool found = false;
		for(size_t i=0;i<in_arcs.size();i++)
			if(in_arcs[i] == a)
			{
				found = true;
				in_arcs.erase(in_arcs.begin() + i);
				break;
			}
		if(!found)
			printf("Error RemoveOutArc from:%d to:%d item:%d\n", a->from, a->to, a->item->origin_id);
	}
} bpp_carvalho_node_t;

class Bpp_Carvalho
{
	public:
		Bpp_Carvalho()
		{
			nbbins = 0;
			max_duration = 1800;
			time_taken=0;
			used_graph = 0;
			nbthreads = 1;
			intsollim = 1000000;
			allow_preprocessing = false;
			solve_problem = true;
			position_split = -1;
			show_cplex_output = false;
		}
		~Bpp_Carvalho(){}


		int Solve(strip_ptr st);

		int position_split;
		int split_in;		//position in which we splited
		int nbthreads;
		int intsollim;
		int nbbins;
		int nbsizes;
		int nbnodes;
		int nbarcs;
		int nblossarcs;
		double time_taken;
		int max_duration;
		int used_graph;		//0=VDC graph, 1=MIM Graph, 2=MIM2 Graph
		bool allow_preprocessing;
		bool solve_problem;
		bool show_cplex_output;
	private:
		void InitGraph();
		void InitMimGraph();

		void EnlargeArcs();
		int RemoveRedundantArcs();

		void InitMasterProblem(IloEnv env);
		void Clear();
		void PrintGraph();
		void ShowArcsForItem();
		void ShowSolution();
		strip_ptr st;


		//variables for the master problem
		IloModel model;
		IloCplex cplex;
		IloNumVar z;					//objective function
		IloNumVarArray x;				//flow variables

		std::vector<bpp_carvalho_node_t> graph;
		std::vector<bpp_carvalho_node_t*> nodes;
		std::vector<bpp_carvalho_arc_t> arcs;
};










#endif
