/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include "positions.h"
#include <math.h>
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "util.h"
#include "mathfunc.h"
#include <limits.h>

void positions_show(positions_set_ptr p)
{
	int i,j;
	for(i=0;i<p->nbsets;i++)
	{
		printf("i:%d nb:%d pos:", i,p->set[i].nb);
		for(j=0;j<p->set[i].nb;j++)
			printf("%d ", p->set[i].pos[j]);
		printf("\n");
	}
	positions_show_global(p);
	printf("split_pos:%d totalpos:%d nbconst:%d\n", p->split_pos,p->nb_total_positions, p->nb);
}

void positions_show_detailed(strip_ptr st,positions_set_ptr p)
{
	int i,j;
	for(i=0;i<p->nbsets;i++)
	{
		printf("i:%d w:%d nb:%d pos:", i,st->items[i].w,p->set[i].nb);
		for(j=0;j<p->set[i].nb;j++)
			printf("%d ", p->set[i].pos[j]);

		//printf("| ");
		//for(j=0;j<p->set[i].nb;j++)
		//	printf("%d ", p->set[i].pos[j] + st->items[i].w);

		printf("\n");
	}
	positions_show_global(p);
	printf("w:%d split_pos:%d totalpos:%d nbconst:%d\n", st->w, p->split_pos,p->nb_total_positions, p->nb);
}

void positions_show_global(positions_set_ptr p)
{
	int i,j;
	printf("global nb:%d pos:", p->nb);
	for(j=0;j<p->nb;j++)
		printf("%d ", p->pos[j]);
	printf("\n");
}




//mim patterns and the split is done is the best possible way for the BPP and 1 is to restrict the smallest in the biggest partition
int positions_calculate_mim_best_split_bpp(strip_ptr st, positions_set_ptr p)
{
	item_ptr items = st->items;
	int * left_pos = (int*)calloc(st->w+1, sizeof(int));
	int * right_pos = (int*)calloc(st->w+1, sizeof(int));
	int * pos = (int*)calloc(st->w+1, sizeof(int));
	int * list = (int*)calloc(st->w+1, sizeof(int));
	p->set = (positions_t *)malloc(sizeof(positions_t) * st->nb);
	p->nbsets = st->nb;
	int i,j,k,l;
	int n = st->nb, w = st->w;
	int w2 = (int)st->w/2;

	for(i=0;i<=w;i++)
	{
		left_pos[i] = 0;
		pos[i] = -1;
	}
	left_pos[0] = -1;


	for(i=0;i<n;i++)
	{
		int wi = items[i].w;
		for(j=w-wi;j>=0;j--)
			if(left_pos[j] != 0)
				for(k=0;k<items[i].nbcopies;k++)
				{
					int from = j+k*wi;
					int to = from + wi;
					if(to > w) break;
					if(pos[to] == i) break;

					left_pos[from] = left_pos[from]<0?1:left_pos[from]+1;
					if(left_pos[to] == 0) left_pos[to] = -1;

					pos[to] = i;

					if(wi <= w2) right_pos[w-to]++;
					//right_pos[w-to]++;
				}
	}

	for(i=0;i<=w;i++)
	{
		if(left_pos[i] < 0)
			left_pos[i] = 0;
	}

	//for(i=0;i<=w;i++)
	//	printf("pos:%d left:%d right:%d\n",i, left_pos[i],right_pos[i]);

	for(i=1;i<=w;i++)
	{
		left_pos[i] += left_pos[i-1];
		right_pos[w - i] += right_pos[w - i + 1];
	}

	int pos_best_split = 1;
	int count = left_pos[0] + right_pos[1];
	//printf("pos:%d count:%d\n", pos_best_split, count);
	for(i=2;i<=w;i++)
	{
		//printf("pos:%d left:%d right:%d count:%d\n", i,left_pos[i-1], right_pos[i],left_pos[i-1] + right_pos[i]);
		if(count > left_pos[i-1] + right_pos[i])
		{
			count = left_pos[i-1] + right_pos[i];
			pos_best_split = i;
		}
	}


	for(i=0;i<=w;i++)
		pos[i] = left_pos[i] = right_pos[i] = 0;
	left_pos[0] = right_pos[w] = 1;

	//printf("Split:%d count:%d w2:%d\n",pos_best_split,count,w2);
	p->split_pos = pos_best_split;
	p->nb_total_positions = 0;
	for(i=0;i<n;i++)
	{
		int nbpos = 0;
		int wi = items[i].w;

		//printf("i:%d left:%d right:%d\n", i, nbcopies_left, nbcopies_right);
		for(j=pos_best_split-1;j>=0;j--)
			if(left_pos[j] >= 1)
				for(k=0;k<items[i].nbcopies;k++)
				{
					int from = j+k*wi;
					int to = from + wi;
					if(to > w || from >= pos_best_split) break;
					if(left_pos[to] == i+1) break;

					left_pos[to] = i+1;
					list[nbpos++] = from;
					pos[from] = 1;
				}

		if(wi <= w2)
			for(j=pos_best_split;j<=w-wi;j++)
				if(right_pos[j+wi] >= 1)
					for(k=0;k<items[i].nbcopies;k++)
					{
						int from = j-k*wi;
						int to = from + wi;
						if(to > w)break;
						if(from < pos_best_split) break;
						if(right_pos[from] == i+1) break;

						right_pos[from] = i+1;
						list[nbpos++] = from;
						pos[from] = 1;
					}

		util_sort_int(list,nbpos);
		p->set[i].pos = malloc(sizeof(positions_t) * nbpos);
		p->set[i].nb = nbpos;
		for(j=0;j<nbpos;j++)
			p->set[i].pos[j] = list[j];
		p->nb_total_positions += nbpos;
	}

	//printf("Split in:%d count:%d total:%d\n", pos_best_split, count,p->nb_total_positions);
	p->nb = 0;
	for(i=0;i<=w;i++)
		p->nb += pos[i];

	p->pos = (int*)malloc(sizeof(int) * p->nb);
	p->nb = 0;
	for(i=0;i<=w;i++)
		if(pos[i] == 1)
			p->pos[p->nb++] = i;

	free(pos);
	free(left_pos);free(right_pos);free(list);
	return p->nb_total_positions;
}



void positions_free(positions_set_ptr p)
{
	int i;
	for(i=0;i<p->nbsets;i++)
		if(p->set[i].pos != NULL)
			free(p->set[i].pos);
	if(p->pos != NULL)
		free(p->pos);
	if(p->set != NULL)
		free(p->set);
	p->set = NULL;
	p->pos = NULL;
}


void positions_create(int n,int * w, int W, int * pos)
{
	unsigned int last = 0;
	/* variables */
	int i,p,a,b; //counter

	// *** initialize ***
	pos[0] = 1;
	for (i = 1; i <= W; i++)
		pos[i] = 0;

	for (i = 0; i < n; i++)
	{
		p = MIN_INT(W-w[i],last);
		b = p + w[i];
		for (;p >= 0; p--,b--)
		{
			pos[b] |= pos[p];
			last = MAX_INT(b * pos[p],last);
		}
	}
}
