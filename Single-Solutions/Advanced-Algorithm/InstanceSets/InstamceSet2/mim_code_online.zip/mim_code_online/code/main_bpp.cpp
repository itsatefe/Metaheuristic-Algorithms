
/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "limits.h"

#include "struct2d.h"
#include "positions.h"
#include "bpp_carvalho.h"
#include "bpp_lb.h"

#include <vector>

#define PARAM_FILE 1
#define PARAM_OUTFILE 2

typedef struct
{
	int nbnodes;
	int nbarcs;
	int nblossarcs;
	int used_graph;
	bool allow_pre;
	char * name;
	int nbbins;
	double time_taken;
} config_t;

void Execute(strip_ptr st, char * in_file, char * outfile);

int main(int arg, char ** argv)
{
	time_t tt = time(0);
	//srand(tt);
	srand(3);

	strip_t strip_bpp; strip_ptr st = &strip_bpp;


	if(arg >= PARAM_FILE+1)
	{
		printf("opening:%s\n", argv[PARAM_FILE]);
		strip_read_bpp(st, argv[PARAM_FILE]);
	}
	else
	{
		printf("No file provided exiting\n");
		exit(3);
	}

	strip_sort_by_width_decreasing_method(st);
	strip_set_no(st);

	//strip_show_bpp(st);
	Execute(st, argv[PARAM_FILE], arg > PARAM_OUTFILE?argv[PARAM_OUTFILE]:NULL);

}


void Execute(strip_ptr st, char * in_file, char * outfile)
{
	std::vector<config_t> configs;


	config_t conf_vc, conf_part, conf_part_pre,conf_mim, conf_pre1;
	conf_vc.used_graph = BPP_CARVALHO; conf_vc.allow_pre = false;
	conf_mim.used_graph = BPP_CARVALHO_MIM; conf_mim.allow_pre = false;
	conf_pre1.used_graph = BPP_CARVALHO_MIM; conf_pre1.allow_pre = true;
	conf_vc.name = (char*)"Vdc";
	conf_mim.name = (char*)"Mim";
	conf_pre1.name = (char*)"Pr1";

	configs.push_back(conf_vc);
	configs.push_back(conf_mim);
	configs.push_back(conf_pre1);

	int csp_lb;
	{
		bpp_lb_t bpp_lb;bzero(&bpp_lb,sizeof(bpp_lb));
		bpp_lb.strip = st;
		Bpp_Lb BppLb(&bpp_lb);

		csp_lb = BppLb.GetLB();
		if(csp_lb == 0) csp_lb = 99999;
		//st->UB = csp_lb+1;
		st->UB = csp_lb+8;
	}

	for(size_t i=0;i<configs.size();i++)
	{
		Bpp_Carvalho bpp;
		bpp.nbthreads = 1;
		bpp.max_duration = 1200;
		bpp.allow_preprocessing = configs[i].allow_pre;
		bpp.used_graph = configs[i].used_graph;
		bpp.solve_problem = true;
		bpp.show_cplex_output = false;
		bpp.Solve(st);
		configs[i].nbarcs = bpp.nbarcs;
		configs[i].nbnodes = bpp.nbnodes;
		configs[i].nbbins = bpp.nbbins;
		configs[i].nblossarcs = bpp.nblossarcs;
		configs[i].time_taken = bpp.time_taken;
	}

	printf("\n\nResults for instance:%s\n",in_file);
	for(size_t i=0;i<configs.size();i++)
	{
		printf("method:%s nbbins:%d duration:%.4lf ",configs[i].name,configs[i].nbbins,configs[i].time_taken);
		printf("nbarcs:%d nbnodes:%d lossarcs:%d ",configs[i].nbarcs,configs[i].nbnodes, configs[i].nblossarcs);
		printf("diff:%d\n", configs[i].nbarcs - configs[i].nblossarcs);
	}



	if(outfile == NULL) return;
	FILE * f = fopen(outfile, "w");
	fprintf(f, "%s;%d;%d;%d;",in_file,st->nb,st->w,csp_lb);

	for(size_t i=0;i<configs.size();i++)
	{
		fprintf(f,"%d;%.4lf;",configs[i].nbbins,configs[i].time_taken);
		fprintf(f,"%d;%d;",configs[i].nbarcs,configs[i].nbnodes);
	}

	int minbins = 9999;
	int maxbins = 0;
	for(size_t i=0;i<configs.size();i++)
	{
		if(configs[i].nbbins != -1 && minbins > configs[i].nbbins)
			minbins = configs[i].nbbins;
		else if(configs[i].nbbins != -1 && maxbins < configs[i].nbbins)
			maxbins = configs[i].nbbins;
	}
	if(maxbins >= 1 && minbins != maxbins)
		fprintf(f,"Error");

	fprintf(f,"\n");
	fclose(f);
}
