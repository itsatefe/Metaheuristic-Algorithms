/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include "bpp_lb.h"
#include <ilcplex/ilocplex.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>

#include "mathfunc.h"
#include "combo.h"


ILOSTLBEGIN


typedef IloArray<IloNumVarArray> NumVarMatrix;


int Bpp_Lb::GetLB()
{
	//printf("ocbpp_cutting_lb::solve() h:%d w:%d\n",info->strip->h,info->strip->w);
	if(info->strip->nb == 0)
	{
		info->was_called = 1;
		return PACKING_FEASIBLE;
	}
	int i,j,k,l,w,h,t;
	st = info->strip;
	n = st->nb;
	info->taken_time = 0;
	pricing_cost = 9999999;

	clock_t start = clock();
	IloEnv env;
	InitMasterProblem(env);



	bool re = false;
	int cont = 0;
	int cplex_status = 0;
	int iter = 0;
	double sol;
	time_t end_time = time(0) + 300;
	int iter_max = 5000;
	bool has_timed_out = false;
	do
	{
		cont = 0;
		re = cplex.solve();
		cplex_status = (int)cplex.getCplexStatus();
		sol = cplex.getObjValue();
		int int_sol = (int)ceil(sol - EPSILON);
		double lb_cost = sol/pricing_cost;
		int lb1 = (int)ceil(sol-EPSILON);
		int lb2 = (int)ceil(lb_cost-EPSILON);

		//#ifdef WITH_OUTPUT
		//printf("Solved:%d status:%d iter:%d value:%.2lf ",re,cplex_status,iter,sol);
		//printf("price:%lf lb_cost:%lf lb1:%d lb2:%d\n", pricing_cost, lb_cost,lb1,lb2);
		//#endif

		if(lb2 >= lb1) break;

		if(iter >= iter_max || ((iter % 50 == 0) && end_time < time(0)))
		{
			has_timed_out = true;
			break;
		}

		cplex.getDuals(duals_vars, consts_vars);
		if(PricingCombo())
			cont = 1;

		iter++;
	}
	while(cont == 1);

	int nb = 0;
	info->lb = (int)ceil(sol - EPSILON);
	if(has_timed_out) info->lb = 0;
	info->taken_time = (clock()-start)/(double)CLOCKS_PER_SEC;

	obj.end();
	x.end();
	consts_vars.end();
	duals_vars.end();
	cplex.end();
	model.end();
	env.end();


	printf("Bpp_Lb final bound:%d sol:%lf iter:%d time:%.2lf\n", info->lb,sol,iter, info->taken_time);
	return info->lb;
}

bool Bpp_Lb::PricingCombo()
{
	bool found_new = false;
	int mul_const = 10000;

	//for(int i=0;i<n;i++)
	//	if(duals_vars[i] > 0)
	//		printf("item:%d dual:%.10lf\n", i, duals_vars[i]);

	int nbitems = 0;
	for(int i=0;i<n;i++)
	{
		if(((int)mul_const*duals_vars[i]) <= 0) continue;

		if(st->items[i].nbcopies * st->items[i].w > st->w)
			nbitems += (int)(st->w / st->items[i].w);
		else
			nbitems += st->items[i].nbcopies;
	}

	int * p = (int*)malloc(sizeof(int) * nbitems);
	int * w = (int*)malloc(sizeof(int) * nbitems);
	int * xi = (int*)calloc(nbitems,sizeof(int));

	std::vector<int> index(nbitems,0);
	std::vector<int> sum(n,0);

	double z1 = 0;
	int nb = 0, nb_in = 0;
	for(int i=0;i<n;i++)
	{
		if(((int)mul_const*duals_vars[i]) <= 0) continue;

		int nbmax = st->items[i].nbcopies;
		if(st->items[i].nbcopies * st->items[i].w > st->w)
			nbmax = (int)(st->w / st->items[i].w);

		for(int j=0;j<nbmax;j++)
		{
			p[nb] = (int)mul_const*duals_vars[i];
			w[nb] = st->items[i].w;
			xi[nb]=0;
			index[nb] = i;
			nb++;
		}
	}

	if(nb <= 1) goto END;

	//int combo_solve(int * p, int * w, int * x, int W,  int n, int lb);
	z1 = (double)combo_solve(p,w,xi,st->w,nb,0);

	//printf("combo z1:%lf\n", z1);
	pricing_cost = z1 / mul_const;

	if(z1-EPSILON <= mul_const) goto END;

	for(int i=0;i<nb;i++)
	{
		nb_in += xi[i];
		sum[ index[i] ] += xi[i];
	}

	if(nb_in <= 1) goto END;
	{
		found_new = true;
		IloNumVar newx = IloNumVar(x.getEnv(),0,IloInfinity, ILOFLOAT);
		x.add(newx);
		obj.setLinearCoef(newx, 1);

		for(int i=0;i<nb;i++)
			if(sum[ index[i] ] >= 1)
				consts_vars[ index[i] ].setLinearCoef(newx, sum[ index[i] ]);
	}

END:
	free(p);free(w);free(xi);
	return found_new;
}

void Bpp_Lb::InitMasterProblem(IloEnv env)
{
	int i;
	model = IloModel(env);
	consts_vars = IloRangeArray(env);
	duals_vars = IloNumArray(env);
	IloExpr obj1(env);
	x = IloNumVarArray(env, n, 0,IloInfinity, ILOFLOAT);

	for(i=0;i<n;i++)
		obj1 += x[i];

	obj = IloMinimize(env, obj1);
	model.add(obj);
	obj1.end();

	for(i=0;i<n;i++)
	{
		IloExpr expr(env);
		expr += x[i];
		consts_vars.add(expr >= st->items[i].nbcopies);
		expr.end();
	}
	model.add(consts_vars);

	cplex = IloCplex(model);
	cplex.setParam(IloCplex::Threads,1);
	cplex.setOut(env.getNullStream());

	//cplex.exportModel("bpp_lb.lp");

	int minw = st->w;
	for(int i=0;i<n;i++)
		if(st->items[i].w < minw)
			minw = st->items[i].w;


	for(int i=0;i<n;i++)
	{
		int nbcol = 0;
		for(int j=i+1;j<n;j++)
			if(st->items[i].w + st->items[j].w >= ((int)0.8 * st->w) && st->items[i].w + st->items[j].w <= st->w)
			{
				IloNumVar newx = IloNumVar(x.getEnv(),0,IloInfinity, ILOFLOAT);
				x.add(newx);
				obj.setLinearCoef(newx, 1);

				consts_vars[ i ].setLinearCoef(newx, 1);
				consts_vars[ j ].setLinearCoef(newx, 1);
				if(++nbcol > 5) break;
			}
	}

	//cplex.exportModel("bpp_lb1.lp");
}
