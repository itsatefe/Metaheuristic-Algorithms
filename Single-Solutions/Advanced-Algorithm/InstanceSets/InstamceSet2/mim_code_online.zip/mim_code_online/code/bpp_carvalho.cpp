/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/


#include "bpp_carvalho.h"
#include <ilcplex/ilocplex.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>

#include "Chrono.h"
#include "util.h"
#include "mathfunc.h"
#include <algorithm>    // std::sort
#include "positions.h"

ILOSTLBEGIN

int Bpp_Carvalho::Solve(strip_ptr strip)
{
	printf("\n\nBpp_Carvalho::Solve W:%d n:%d\n",strip->w,strip->nb);
	st = strip;
	nbbins = -1;
	nbnodes = nbarcs = nblossarcs = 0;
	split_in = -1;
	ChronoRealNoStop chrono;chrono.start();

	IloEnv env;
	if(used_graph == BPP_CARVALHO_MIM)
		InitMimGraph();
	else
		InitGraph();
	//ShowArcsForItem();
	//PrintGraph();
	//return 1;

	if(!solve_problem)
		return 0;

	InitMasterProblem(env);


	bool re = cplex.solve();
	int cplex_status = (int)cplex.getCplexStatus();
	if(re && cplex_status == (int)IloCplex::Optimal)
		nbbins = (int)(cplex.getObjValue()+0.5);

	//ShowSolution();
	time_taken = chrono.getTime();
	printf("Bpp_Carvalho NbBins:%d Time:%.3lf nbarcs:%d nbnodes:%d re:%d status:%d split:%d\n", nbbins, time_taken,nbarcs, (int)nodes.size(),(int)re,cplex_status,split_in);
	//ShowSolution();

	Clear();
	env.end();
	return nbbins;
}


void Bpp_Carvalho::InitGraph()
{
	printf("InitGraph() Classical VDC\n");
	//strip_sort_by_width_decreasing_method(st);
	graph.clear();
	graph.resize( st->w+1 );
	for(int i=0;i<=st->w;i++)
		graph[i].pos = i;

	int nbmaxarcs = 0;
	for(int i=0;i<st->nb;i++)
		nbmaxarcs += st->w*st->items[i].nbcopies;
	arcs.resize(nbmaxarcs);


	nbarcs = 0;
	for(int i=0;i<st->nb;i++)
	{
		int wi = st->items[i].w;
		for(int j=st->w-wi;j>=0;j--)
			if(graph[j].HasInArcs() || j == 0)
			{
				for(int k=0;k<st->items[i].nbcopies;k++)
				{
					int from = j+k*wi;
					int to = j+(k+1)*wi;
					if(to > st->w) break;
					if(graph[from].GetLastArcWidth() == wi) continue;

					arcs[nbarcs].from = from;
					arcs[nbarcs].to = to;
					arcs[nbarcs].w = wi;
					arcs[nbarcs].item = &st->items[i];
					graph[ from ].arcs.push_back( &arcs[nbarcs] );
					graph[ to ].in_arcs.push_back( &arcs[nbarcs] );
					nbarcs++;
				}
			}
	}

	if(allow_preprocessing) EnlargeArcs();

	nblossarcs = 0;
	//add loss arcs from the node sw to W
	if(!allow_preprocessing)
		for(int i=st->items[ st->nb-1 ].w;i<st->w;i++)
		{
			arcs[nbarcs].from = i;
			arcs[nbarcs].to = i+1;
			arcs[nbarcs].w = 1;
			arcs[nbarcs].item = NULL;
			graph[ i ].arcs.push_back( &arcs[nbarcs] );
			graph[ i+1 ].in_arcs.push_back( &arcs[nbarcs] );
			nbarcs++;
			nblossarcs++;
		}
	//printf("nbmaxarcs:%d nbarcs:%d\n", nbmaxarcs,nbarcs);

	nodes.clear();
	for(int i=0;i<=st->w;i++)
		if(graph[i].HasArcs() || graph[i].HasInArcs())
			nodes.push_back( &graph[i] );

	if(allow_preprocessing)
		for(int i=0;i+1<nodes.size();i++)
			if(!nodes[i]->ContainsArcsOfW(nodes[i+1]->pos - nodes[i]->pos))
			{
				//printf("adding loss arc from:%d to:%d\n",nodes[i]->pos,nodes[i+1]->pos);
				arcs[nbarcs].from = nodes[i]->pos;
				arcs[nbarcs].to = nodes[i+1]->pos;
				arcs[nbarcs].w = nodes[i+1]->pos - nodes[i]->pos;
				arcs[nbarcs].item = NULL;
				nodes[i]->arcs.push_back( &arcs[nbarcs] );
				nodes[i+1]->in_arcs.push_back( &arcs[nbarcs] );
				nbarcs++;
				nblossarcs++;
			}

	nbarcs = 0;
	for(int i=0;i<nodes.size();i++)
		nbarcs += (int)nodes[i]->arcs.size();

	nbnodes = (int)nodes.size();
	printf("InitGraph nbnodes:%d nbarcs:%d\n", nbnodes,nbarcs);
}

void Bpp_Carvalho::InitMimGraph()
{
	//printf("InitMimGraph() MIM\n");
	positions_set_t pos;
	positions_calculate_mim_best_split_bpp(st, &pos);
	//positions_show_detailed(st,&pos);

	arcs.resize(pos.nb_total_positions + st->w);
	graph.clear();
	graph.resize( st->w+1 );
	for(int i=0;i<=st->w;i++)
		graph[i].pos = i;

	nbarcs = 0;
	for(int i=0;i<st->nb;i++)
		for(int j=0;j<pos.set[i].nb;j++)
		{
			int from = pos.set[i].pos[j];
			int to = from + st->items[i].w;
			arcs[nbarcs].from = from;
			arcs[nbarcs].to = to;
			arcs[nbarcs].w = st->items[i].w;
			arcs[nbarcs].item = &st->items[i];
			graph[ from ].arcs.push_back( &arcs[nbarcs] );
			graph[ to ].in_arcs.push_back( &arcs[nbarcs] );
			nbarcs++;
		}



	if(allow_preprocessing) EnlargeArcs();

	//add loss arcs only for nodes having in or out arcs
	nodes.clear();
	for(int i=0;i<=st->w;i++)
		if(graph[i].HasArcs() || graph[i].HasInArcs())
			nodes.push_back( &graph[i] );

	//add loss arcs
	nblossarcs = 0;
	for(int i=0;i+1<nodes.size();i++)
		if(!nodes[i]->ContainsArcsOfW(nodes[i+1]->pos - nodes[i]->pos))
		{
			//printf("adding loss arc from:%d to:%d\n",nodes[i]->pos,nodes[i+1]->pos);
			arcs[nbarcs].from = nodes[i]->pos;
			arcs[nbarcs].to = nodes[i+1]->pos;
			arcs[nbarcs].w = nodes[i+1]->pos - nodes[i]->pos;
			arcs[nbarcs].item = NULL;
			nodes[i]->arcs.push_back( &arcs[nbarcs] );
			nodes[i+1]->in_arcs.push_back( &arcs[nbarcs] );
			nbarcs++;
			nblossarcs++;
		}

	//printf("with loss arcs nbarcs:%d\n", nbarcs);
	nbarcs = 0;
	for(int i=0;i<nodes.size();i++)
		nbarcs += (int)nodes[i]->arcs.size();

	nbnodes = (int)nodes.size();
	printf("InitMimGraph nbnodes:%d nbarcs:%d lossarcs:%d split:%d\n", nbnodes,nbarcs-nblossarcs,nblossarcs, pos.split_pos);
	split_in = pos.split_pos;
	positions_free(&pos);
}


void Bpp_Carvalho::EnlargeArcs()
{
	int nb_move_back = 0, nb_move_forward = 0;

	do
	{
		//if there are no incoming arcs at a given node,
		//then we move them all to the first previous node thave have incoming arcs
		int last_start = 0;
		for(size_t i=1;i<graph.size();i++)
		{
			if(graph[i].arcs.size() + graph[i].in_arcs.size() == 0) continue;

			if(graph[i].in_arcs.size() >= 1)
				last_start = (int)i;
			else
			{
				for(size_t j=0;j<graph[i].arcs.size();j++)
				{
					bpp_carvalho_arc_t* a = graph[i].arcs[j];
					graph[last_start].arcs.push_back(a);
				//	printf("moving it:%d from:%d to:%d -> from:%d to:%d\n",a->item->no, a->from, a->to, last_start,a->to);
					a->from = last_start;
					a->w = a->to - a->from;
					nb_move_back++;
				}
				graph[i].arcs.clear();
			}
		}

		int last_end = graph.size()-1;
		for(int i= (int)graph.size()-2;i>=0;i--)
		{
			if(graph[i].arcs.size() + graph[i].in_arcs.size() == 0) continue;

			if(graph[i].arcs.size() >= 1)
				last_end = i;
			else
			{
				for(size_t j=0;j<graph[i].in_arcs.size();j++)
				{
					bpp_carvalho_arc_ptr a = graph[i].in_arcs[j];
					graph[last_end].in_arcs.push_back(a);
					//printf("moving it:%d from:%d to:%d -> from:%d to:%d\n",a->item->no, a->from, a->to, a->from,last_end);
					a->to = last_end;
					a->w = a->to - a->from;
					nb_move_forward++;
				}
				graph[i].in_arcs.clear();
			}
		}
	}
	while(RemoveRedundantArcs() >= 1);
	printf("nb_move_back:%d nb_move_forward:%d\n",nb_move_back,nb_move_forward);
}


int Bpp_Carvalho::RemoveRedundantArcs()
{
	//printf("Graph_Pos::RemoveRedundantArcs()\n");
	int nbremoved = 0;
	for(size_t i=0;i<graph.size();i++)
	{
		for(size_t j=0;j<graph[i].arcs.size();j++)
			graph[i].arcs[j]->flag = 0;
		for(size_t j=0;j<graph[i].in_arcs.size();j++)
			graph[i].in_arcs[j]->flag = 0;
	}

	for(size_t i=0;i<graph.size();i++)
	{
		std::vector<bpp_carvalho_arc_ptr> lengths(st->nb,NULL);
		for(size_t j=0;j<graph[i].arcs.size();j++)
		{
			bpp_carvalho_arc_ptr a = graph[i].arcs[j];
			if(lengths[a->item->no] == NULL)
				lengths[a->item->no] = a;
			else
			{
				nbremoved++;
				if(a->to - a->from < lengths[a->item->no]->to - lengths[a->item->no]->from)
				{
					lengths[a->item->no]->flag = 1;
					lengths[a->item->no] = a;
				}
				else
					a->flag = 1;
			}
		}
	}

	for(size_t i=0;i<graph.size();i++)
	{
		std::vector<bpp_carvalho_arc_ptr> lengths(st->nb,NULL);
		for(size_t j=0;j<graph[i].in_arcs.size();j++)
		{
			bpp_carvalho_arc_ptr a = graph[i].in_arcs[j];
			if(a->flag == 1) continue;

			if(lengths[a->item->no] == NULL)
				lengths[a->item->no] = a;
			else
			{
				nbremoved++;
				if(a->to - a->from < lengths[a->item->no]->to - lengths[a->item->no]->from)
				{
					lengths[a->item->no]->flag = 1;
					lengths[a->item->no] = a;
				}
				else
					a->flag = 1;
			}
		}
	}

	for(size_t i=0;i<graph.size();i++)
	{
		std::vector<bpp_carvalho_arc_ptr> arcs;
		for(size_t j=0;j<graph[i].arcs.size();j++)
			if(graph[i].arcs[j]->flag == 0)
				arcs.push_back(graph[i].arcs[j]);
		if(graph[i].arcs.size() != arcs.size())
			graph[i].arcs = arcs;
		arcs.clear();

		for(size_t j=0;j<graph[i].in_arcs.size();j++)
			if(graph[i].in_arcs[j]->flag == 0)
				arcs.push_back(graph[i].in_arcs[j]);
		if(graph[i].in_arcs.size() != arcs.size())
			graph[i].in_arcs = arcs;
	}

	printf("Bpp_Carvalho::RemoveRedundantArcs:%d\n", nbremoved);
	return nbremoved;
}

void Bpp_Carvalho::InitMasterProblem(IloEnv env)
{
	int i;
	model = IloModel(env);
	IloExpr obj1(env);
	z = IloNumVar(env, 0, IloInfinity,ILOINT);
	{
		char name[20];
		sprintf(name,"z");
		z.setName(name);
	}


	x = IloNumVarArray(env, nbarcs, 0, IloInfinity, ILOINT);
	for(int i=0;i<nbarcs;i++)
	{
		char name[20];
		sprintf(name,"x%d.%d.%d",arcs[i].from,arcs[i].to,arcs[i].w);
		x[i].setName(name);
	}

	int index = 0;
	for(size_t i=0;i<nodes.size();i++)
		for(size_t j=0;j<nodes[i]->arcs.size();j++)
			nodes[i]->arcs[j]->index = index++;

	IloExpr obj(env);
	obj += z;
	model.add(IloMinimize(env, obj));
	obj.end();

	for(size_t i=0;i<nodes.size();i++)
	{
		IloExpr expr(env);

		for(size_t j=0;j<nodes[i]->in_arcs.size();j++)
			expr += x[ nodes[i]->in_arcs[j]->index ];
		for(size_t j=0;j<nodes[i]->arcs.size();j++)
			expr -= x[ nodes[i]->arcs[j]->index ];

		if(nodes[i]->pos == 0)
			expr += z;
		else if(nodes[i]->pos == st->w)
			expr -= z;

		model.add( expr == 0 );
		expr.end();
	}

	for(i=0;i<st->nb;i++)
	{
		IloExpr expr(env);

		for(size_t j=0;j<nodes.size();j++)
			for(size_t k=0;k<nodes[j]->arcs.size();k++)
				if(nodes[j]->arcs[k]->item == &st->items[i])
					expr += x[ nodes[j]->arcs[k]->index ];

		model.add( expr >= st->items[i].nbcopies );
		expr.end();
	}

	cplex = IloCplex(model);
	cplex.setParam(IloCplex::Threads,nbthreads);
	//cplex.setParam(IloCplex::RootAlg, 4);
	//cplex.setParam(IloCplex::NodeAlg, 4);
	cplex.setParam(IloCplex::CutUp, st->UB + EPSILON);
	//cplex.setParam(IloCplex::HeurFreq,1);
	//cplex.setParam(IloCplex::IntSolLim,intsollim);
	if(!show_cplex_output) cplex.setOut(env.getNullStream());
	cplex.setParam(IloCplex::TiLim,max_duration);

	//cplex.exportModel("bpp.lp");
	printf("Bpp_Carvalho::InitMasterProblem UB:%d\n",  st->UB);
}

void Bpp_Carvalho::Clear()
{
	z.end();
	x.end();
	cplex.end();
	model.end();
}

void Bpp_Carvalho::PrintGraph()
{
	printf("PrintGraph() nodes:%d arcs:%d\n", (int)nodes.size(), nbarcs);

	for(size_t i=0;i<=st->w;i++)
		if(graph[i].in_arcs.size() + graph[i].arcs.size() >= 1)
			printf("Node:%d nbin:%d nbout:%d\n", graph[i].pos, (int)graph[i].in_arcs.size(),(int)graph[i].arcs.size());

}
void Bpp_Carvalho::ShowArcsForItem()
{
	printf("ShowArcsForItem() W:%d\n",st->w);
	for(int i=0;i<st->nb;i++)
	{
		printf("item:%d w:%d copies:%d from:", i,st->items[i].w,st->items[i].nbcopies);
		std::vector<int> positions;

		for(size_t j=0;j<nodes.size();j++)
			for(size_t k=0;k<nodes[j]->arcs.size();k++)
				if(nodes[j]->arcs[k]->item == &st->items[i])
					positions.push_back(nodes[j]->arcs[k]->from);
					//printf("(%d %d) ",i, arcs[j].from);
					//printf("%d(%d) ",arcs[j].from,arcs[j].to);
		std::sort (positions.begin(), positions.end());
		for(size_t j=0;j<positions.size();j++)
			printf("%d ", positions[j]);
		printf("\n");
		for(size_t j=1;j<positions.size();j++)
			if(positions[j-1] == positions[j])
			{
				printf("item:%d has the several times the same position:%d\n", i, positions[j]);
				i=st->nb;
				break;
			}

	}
	printf("loss arcs:");
	for(size_t j=0;j<nodes.size();j++)
		for(size_t k=0;k<nodes[j]->arcs.size();k++)
			if(nodes[j]->arcs[k]->item == NULL)
			printf("%d ",nodes[j]->arcs[k]->from);
	printf("\n");
}

void Bpp_Carvalho::ShowSolution()
{
	printf("Solution:\n");
	/*for(int i=0;i<nbarcs;i++)
	{
		double v = cplex.getValue(x[i]);
		if(v < 0.1) continue;
		if(arcs[i].item != NULL)
			printf("i:%d from:%d to:%d w:%d item:%d nb:%d v:%.2lf\n", i, arcs[i].from,arcs[i].to,arcs[i].w,arcs[i].item->no,arcs[i].item->nbcopies,v);
	}*/

	for(int i=0;i<st->nb;i++)
	{
		for(size_t j=0;j<nodes.size();j++)
			for(size_t k=0;k<nodes[j]->arcs.size();k++)
				if(nodes[j]->arcs[k]->item == &st->items[i])
				{
					bpp_carvalho_arc_ptr a = nodes[j]->arcs[k];
					double v = cplex.getValue( x[ a->index ] );
					if(v < 0.1) continue;

					printf("i:%d from:%d to:%d w:%d item:%d nb:%d v:%.2lf\n",
						i,a->from,a->to,a->w,a->item->no,a->item->nbcopies,v);
				}

	}
	for(size_t j=0;j<nodes.size();j++)
		for(size_t k=0;k<nodes[j]->arcs.size();k++)
			if(nodes[j]->arcs[k]->item == NULL)
			{
				bpp_carvalho_arc_ptr a = nodes[j]->arcs[k];
				double v = cplex.getValue( x[ a->index ] );
				if(v < 0.1) continue;
				printf("Loss arc from:%d to:%d v:%.2lf\n", a->from,a->to,v);
			}
}
