
/* ======================================================================
      	     combo.h,    S.Martello, D.Pisinger, P.Toth     feb 1997
   ====================================================================== */

/* This is the header file of the COMBO algorithm described in
 * S.Martello, D.Pisinger, P.Toth: "Dynamic Programming and Strong
 * Bounds for the 0-1 Knapsack Problem".
 *
 *
 * Modification of the header
 * by Jean-François Côté
 */


#ifndef COMBO
#define COMBO

#ifdef __cplusplus
	extern "C" {
#endif


//return the maximum number of items that can fit in W
int combo_solve_get_max_nb_items(int * w, int W, int n);

//return only the maximum profit
int combo_solve_get_z(int * p, int * w, int W, int n);

//return only the maximum profit
int combo_solve_subset_sum_get_z(int * w, int W, int n);

//return the maximum profit and x is an array indicating if the item is in or not (0 or 1)
int combo_solve(int * p, int * w, int * x, int W,  int n, int lb);

int combo_lift_cover_inequality(int nb_in, int * w_in, int nb_out, int * w_out, int * coefs, int W);

//this one doesn't work
int combo_generalized_lifted_cover_inequality(int n, int * w, double * v, int nb_cover, int * cover, int * coefs, int W);

#ifdef __cplusplus
	}
#endif

#endif

