/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

#include "struct2d.h"
#include <math.h>
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

void strip_init(strip_ptr st)
{
	st->w = 0;
	st->nb = 0;
	st->UB = 999999;
	st->LB = 0;
	st->items = NULL;
}




void strip_read_bpp(strip_ptr st, char * filename)
{
	int i,j,n = 0;
	int W;

	FILE * f = fopen(filename, "r");
	if(f == NULL)
	{
		printf("Could not find the file %s\n", filename);
		exit(0);
	}

	int r=0;
	fscanf(f,"%d\n", &n);
	fscanf(f,"%d\n", &W);

	int nbsizes = 0;
	int * ws = (int*)calloc(W+1, sizeof(int));
	for(i=0;i<n;i++)
	{
		int w,nb;
		fscanf(f,"%d\n",&w);
		if(ws[w] == 0)
			nbsizes++;
		ws[w]++;
	}
	strip_init(st);
	st->problem_type = PROBLEM_TYPE_1DBPP;
	st->w = W;
	st->nb = nbsizes;
	strip_init_items(st, nbsizes);
	n = 0;
	for(i=0;i<=W;i++)
		if(ws[i] >= 1)
		{
			st->items[n].w = i;
			st->items[n].origin_id = n;
			st->items[n].no = n;
			st->items[n].nbcopies = ws[i];
			n++;
		}
	fclose(f);
	free(ws);
}




void strip_init_items(strip_ptr st, int n)
{
	st->items = (item_t*)malloc(sizeof(item_t) * n);
	memset(st->items, 0, sizeof(item_t) * n);
}



void strip_free(strip_ptr st)
{
	if(st->items != NULL) free(st->items);
}



void strip_show_bpp(strip_ptr st)
{
	printf("strip_show n:%d w:%d\n",st->nb,st->w);
	int i,j,k;
	for(i=0;i<st->nb;i++)
	{
		item_ptr it = &st->items[i];
		printf("Item:%2d w:%2d nb:%2d\n", it->origin_id,it->w,it->nbcopies);

	}
}


void strip_set_no(strip_ptr st)
{
	int i;
	for(i=0;i<st->nb;i++)
		st->items[i].no = i;
}

int item_sort_width_decreasing(const void *a, const void *b)
{
	item_ptr a1 = (item_ptr)a;
   item_ptr b1 = (item_ptr)b;
   return b1->w - a1->w;
}

void strip_sort_by_width_decreasing_method(strip_ptr st)
{
	int i;
	qsort(st->items, st->nb, sizeof(item_t), item_sort_width_decreasing);
	for(i=0;i<st->nb;i++)
		st->items[i].no = i;
}
