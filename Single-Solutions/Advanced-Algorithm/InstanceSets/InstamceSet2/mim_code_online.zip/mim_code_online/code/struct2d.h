/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/

/*
	Structures to solve 2d packing problems
	by Jean-Francois Cote 2017

	Inspired by the code of Manuel Iori
	(some pieces might be taken from him)
*/

//#ifndef WITH_OUTPUT
//#define WITH_OUTPUT
//#endif


#ifndef STRUCT2D_H
#define STRUCT2D_H

#ifdef __cplusplus
	extern "C" {
#endif

#include "time.h"

#define PACKING_FEASIBLE 1
#define PACKING_INFEASIBLE 0
#define PACKING_UNDETERMINED 2
#define PACKING_TIME_LIMIT_REACHED 3
#define PACKING_NODE_LIMIT_REACHED 4

#define MAX_PACK_ITEMS 500
#define MAX_ITEMS_IS_BIG_PROBLEM 501

#define OCBPP_ON_X 1
#define OCBPP_ON_Y 2
#define OCBPP_SET_INIT_CAP 10;

#define MAX_INFO_PH2 2000

#define PROBLEM_TYPE_2DOPP 1	//2D Orthogonal packing problem
#define PROBLEM_TYPE_2DSPP 2	//2D Strip Packing Problem
#define PROBLEM_TYPE_1DBPP 3	//1D Bin packing problem
#define PROBLEM_TYPE_3DOPP 4	//3D Orthogonal packing
#define PROBLEM_TYPE_2DCSP 5	//2D Cutting stock problem
#define PROBLEM_TYPE_CKP_WEIGHTED_COUNT 6	//2DCKP items have a profit and a max # of copies allowed : istanze_wc
#define PROBLEM_TYPE_CKP_AREA_COUNT 7		//2DCKP profits are equal to the area and a maximal # of copies allowed : istanze_uc
#define PROBLEM_TYPE_CKP_WEIGHT_NOCOUNT 8	//2DCKP items have a profit and no ub on the allowed copies : instanze_wu
#define PROBLEM_TYPE_CKP_AREA_NOCOUNT 9		//2DCKP profit is equal to the area and no ub on the allowed copies : istanze_uu



//struct for the items
typedef struct
{
	int origin_id;		/* original id of the item */
	int no;				//modifiable no to be used by algorithms
	int w;				/* width (x) */
	int x;
	int tag;
	int sort;			//for sorting
	int nbcopies;		//indicate the number of copies of the same items
	int copie_no;
} item_t;
typedef item_t* item_ptr;



typedef struct			//set of items for which we try to solve the packing problem
{
	int w;							//width of the packing area
	int UB;							//Upper bound on the height of the strip
	int LB;							//Lower bound on the height of the strip
	int nb;							//number of sets in the strip
	item_t* items;					//pointer to a list of items
	int problem_type;				//type of problem from the PROBLEM_TYPE defines
} strip_t;
typedef strip_t* strip_ptr;



void strip_init(strip_ptr s); //initialize all the fields
void strip_init_items(strip_ptr st, int nbitems);

void strip_read_bpp(strip_ptr s, char * filename);				//open a data file for the 1D Bin Packing


void strip_show_bpp(strip_ptr st);

void strip_free(strip_ptr st);
void strip_set_no(strip_ptr st);


int item_sort_width_decreasing(const void *a, const void *b);


void strip_sort_by_width_decreasing_method(strip_ptr st);




#ifdef __cplusplus
	}
#endif

#endif
