/*
 * Copyright Jean-Francois Cote 2017
 *
 * The code may be used for academic, non-commercial purposes only.
 *
 * Please contact me at jean-francois.cote@fsa.ulaval.ca for questions
 *
 * If you have improvements, please contact me!
 *
*/
/*
	Solve the root node of the Gilmore and Gomory model the bin packing problem

*/


#ifndef BPP_LB
#define BPP_LB

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <ilcplex/ilocplex.h>
#include "struct2d.h"
#include "time.h"
#include <vector>
#include <map>


typedef struct
{
	int status;			//0 = infeasible, 1 = feasible solution found
	strip_ptr strip;
	int was_called;
	time_t endtime;
	double taken_time;

	int lb;
} bpp_lb_t;

typedef bpp_lb_t* bpp_lb_ptr;

class Bpp_Lb
{
	public:
		Bpp_Lb(bpp_lb_ptr info_ptr)
		{
			info = info_ptr;
		}
		~Bpp_Lb(){}

		void InitMasterProblem(IloEnv env);
		void InitPricingProblem();
		int GetLB();
		bool PricingCombo();

	private:
		bpp_lb_ptr info;
		int n;
		strip_ptr st;


		//variables for the master problem
		IloModel model;
		IloObjective obj;
		IloCplex cplex;
		IloNumVarArray x;
		IloRangeArray consts_vars;		//constraints for the items
		IloNumArray duals_vars;

		int iteration;
		double lb;
		double pricing_cost;
};



#endif
