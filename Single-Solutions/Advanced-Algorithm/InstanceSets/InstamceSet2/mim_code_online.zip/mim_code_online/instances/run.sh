#!/bin/bash -l




./exec_bpp N1C1W1_A.txt
./exec_bpp N1C1W1_B.txt
./exec_bpp N1C1W1_C.txt
